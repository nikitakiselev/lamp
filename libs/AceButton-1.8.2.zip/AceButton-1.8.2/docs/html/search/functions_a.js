var searchData=
[
  ['setbuttonconfig_115',['setButtonConfig',['../classace__button_1_1AceButton.html#a04b7e1d44e41481d2c36501262e35a04',1,'ace_button::AceButton']]],
  ['setclickdelay_116',['setClickDelay',['../classace__button_1_1ButtonConfig.html#aef65e12128997c46bc2754a988b98f14',1,'ace_button::ButtonConfig']]],
  ['setdebouncedelay_117',['setDebounceDelay',['../classace__button_1_1ButtonConfig.html#a9860d2c8a6ab33d40ea126b02d168cab',1,'ace_button::ButtonConfig']]],
  ['setdoubleclickdelay_118',['setDoubleClickDelay',['../classace__button_1_1ButtonConfig.html#a367a809017e1d633a5cf6b117981d579',1,'ace_button::ButtonConfig']]],
  ['seteventhandler_119',['setEventHandler',['../classace__button_1_1AceButton.html#a7769fa58769bc4cf0a0ea9c68072d4de',1,'ace_button::AceButton::setEventHandler()'],['../classace__button_1_1ButtonConfig.html#af916ea5ae0194afeac3a6fd6e25a13d1',1,'ace_button::ButtonConfig::setEventHandler()']]],
  ['setfeature_120',['setFeature',['../classace__button_1_1ButtonConfig.html#adf3a103f188bb8e669c77ab852553e9a',1,'ace_button::ButtonConfig']]],
  ['setieventhandler_121',['setIEventHandler',['../classace__button_1_1ButtonConfig.html#a6fda9545052a13d64b383d11ceea5806',1,'ace_button::ButtonConfig']]],
  ['setlongpressdelay_122',['setLongPressDelay',['../classace__button_1_1ButtonConfig.html#a7d90d39aeddacb5abc9d8741611d7c4a',1,'ace_button::ButtonConfig']]],
  ['setrepeatpressdelay_123',['setRepeatPressDelay',['../classace__button_1_1ButtonConfig.html#af813c969eddd884e9fa83b334a59a0a5',1,'ace_button::ButtonConfig']]],
  ['setrepeatpressinterval_124',['setRepeatPressInterval',['../classace__button_1_1ButtonConfig.html#aa1b1217e0042512fc8d9b6544536aed3',1,'ace_button::ButtonConfig']]]
];
